<%@ page language="java" 
		 contentType="text/html; charset=UTF-8"
    	 pageEncoding="UTF-8"%>
    	 
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>계산 결과</title>
</head>
<body>

	<h2>계산 결과</h2>
	<h2>
		<%= request.getAttribute("operation") %>
		=
		<%= request.getAttribute("result") %>
	</h2>
	

</body>
</html>